package stern

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"errors"
	"fmt"
	"hash"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"

	"golang.org/x/crypto/argon2"
	"golang.org/x/crypto/chacha20poly1305"
	"golang.org/x/crypto/hkdf"
	"golang.org/x/crypto/sha3"
	"golang.org/x/term"
)

const (
	MaxReadLineBuf = 32 * 1024
)

func EncryptOnce(key, data, add []byte) []byte {
	hk := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		key,
		add,
		[]byte("stern-onetime-encrypt-extract-secrets"))

	aesStreamKey := extractSecret(hk, StreamKeySize)
	aesNonce := extractSecret(hk, NonceSize)
	chachaStreamKey := extractSecret(hk, StreamKeySize)
	chachaNonce := extractSecret(hk, chacha20poly1305.NonceSize)

	aead := createAEAD(aesStreamKey)

	res := make([]byte, len(data)+Overhead*2)
	aead.Seal(
		res[:0],
		aesNonce,
		data,
		[]byte("stern-aes-onetime"))

	aead, err := chacha20poly1305.New(chachaStreamKey)
	if err != nil {
		panic(err)
	}

	aead.Seal(
		res[:0],
		chachaNonce,
		res[:len(res)-Overhead],
		[]byte("stern-chacha20poly1305-onetime"))
	return res
}

func DecryptOnce(key, data, add []byte) []byte {
	hk := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		key,
		add,
		[]byte("stern-onetime-encrypt-extract-secrets"))

	aesStreamKey := extractSecret(hk, StreamKeySize)
	aesNonce := extractSecret(hk, NonceSize)
	chachaStreamKey := extractSecret(hk, StreamKeySize)
	chachaNonce := extractSecret(hk, chacha20poly1305.NonceSize)

	aead, err := chacha20poly1305.New(chachaStreamKey)
	if err != nil {
		panic(err)
	}

	res, err := aead.Open(
		nil,
		chachaNonce,
		data,
		[]byte("stern-chacha20poly1305-onetime"))

	if err != nil {
		panic(err)
	}

	aead = createAEAD(aesStreamKey)
	_, err = aead.Open(
		res[:0],
		aesNonce,
		res,
		[]byte("stern-aes-onetime"))
	if err != nil {
		panic(err)
	}
	return res[:len(res)-Overhead]
}

func defaultHashFunc() hash.Hash {
	return sha3.New512()
}

func extractSecret(r io.Reader, size int) (secret []byte) {
	secret = make([]byte, size)
	if _, err := io.ReadFull(r, secret); err != nil {
		panic(err)
	}
	return
}

func createSalt(all ...[]byte) []byte {
	h := sha3.New512()
	for _, i := range all {
		if _, err := h.Write(i); err != nil {
			panic(err)
		}
	}
	r := h.Sum(nil)
	return r[:]
}

func readLine(src io.Reader, delim byte) string {
	oneByte := make([]byte, 1)
	collected := make([]byte, 0, 32)

	for {
		c, err := src.Read(oneByte)
		if err != nil && err != io.EOF {
			panic(err)
		}

		if err == io.EOF {
			return string(collected)
		}

		if c != 0 {
			if oneByte[0] == delim {
				break
			} else {
				collected = append(collected, oneByte...)
			}
		}
		if len(collected) == MaxReadLineBuf+1 {
			panic("line too long")
		}
	}
	return string(collected)
}

func clearLine(out io.Writer) {
	fmt.Fprintf(out, "\n\033[F\033[K")
}

func readPassword(prompt string) []byte {
	tty, err := os.OpenFile("/dev/tty", os.O_RDWR, 0)
	if err != nil {
		panic(err)
	}
	fmt.Fprint(tty, prompt)
	pwd, err := term.ReadPassword(int(tty.Fd()))
	if err != nil {
		panic("read password: internal error: " + err.Error())
	}
	clearLine(tty)
	return pwd
}

func readPasswordForEncryption() []byte {
	pwdRaw := readPassword("Password: ")
	if !isBadPassword(pwdRaw) {
		log.Fatal("Password invalid, only space characters provided")
	}

	pwd := readPassword("Confirm: ")
	if !bytes.Equal(pwd, pwdRaw) {
		log.Fatal("Passwords do not match")
	}
	return pwd
}

func isBadPassword(pwd []byte) bool {
	return len(bytes.TrimSpace(pwd)) != 0
}

var FilesNotEqualByHash = errors.New("files not equal by hash")
var FilesNotEqualBySize = errors.New("files not equal by size")

func SafeCopyToFileFast(filename string, src io.Reader) (err error) {
	return safeCopyToFile(filename, src, false)
}

func SafeCopyToFile(filename string, src io.Reader) (err error) {
	return safeCopyToFile(filename, src, true)
}

func safeCopyToFile(filename string, src io.Reader, byHash bool) (err error) {
	var h hash.Hash
	if byHash {
		h = sha256.New()
	}
	tempfile, err := os.CreateTemp(filepath.Dir(filename), "sterntempfile")
	if err != nil {
		panic(err)
	}
	defer tempfile.Close()

	buf := &bytes.Buffer{}
	var mainErr error
	var c, total int64
	for mainErr == nil {
		c, mainErr = io.CopyN(buf, src, 32*1024)
		if mainErr != nil && mainErr != io.EOF {
			panic(err)
		}
		if c == 0 {
			continue
		}
		total += c
		if byHash {
			_, err = h.Write(buf.Bytes())
			if err != nil {
				panic(err)
			}
		}

		_, err = io.Copy(tempfile, buf)
		if err != nil && err != io.EOF {
			panic(err)
		}

		if mainErr == io.EOF {
			break
		}
	}

	tmp, err := os.Open(tempfile.Name())
	if err != nil {
		panic(err)
	}
	defer os.Remove(tempfile.Name())

	stat, err := tempfile.Stat()
	if err != nil {
		panic(err)
	}
	if stat.Size() != total {
		err = FilesNotEqualBySize
		return
	}

	if byHash {
		h1 := h.Sum(nil)
		h.Reset()

		if _, err := io.Copy(h, tmp); err != nil {
			panic(err)
		}

		h2 := h.Sum(nil)

		if !bytes.Equal(h1[:], h2[:]) {
			err = FilesNotEqualByHash
			return
		}
	}

	if err := tempfile.Sync(); err != nil {
		panic(err)
	}

	if err := os.Rename(tempfile.Name(), filename); err != nil {
		panic(err)
	}

	return
}

func readFromTerminal(prompt string) string {
	tty, err := os.OpenFile("/dev/tty", os.O_RDWR, 0)
	if err != nil {
		panic(err)
	}

	fmt.Fprint(tty, prompt)
	scanner := bufio.NewScanner(tty)
	var lines []string
	var c uint8
	for scanner.Scan() {
		line := scanner.Text()
		lines = append(lines, line)
		c += 1
		if c == 1 {
			break
		}
	}

	err = scanner.Err()
	if scanner.Err() != nil {
		log.Fatal(err)
	}

	line := strings.TrimSpace(strings.Join(lines, " "))
	return line
}

func parseKeys(r io.Reader, onlySecret, onlySub bool) (pub *PubKey, sec *SecKey, sub []byte) {
	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		raw := scanner.Text()
		if len(raw) < SecKeyEncSize {
			continue
		}
		raw = strings.TrimSpace(raw)

		if !onlySecret && raw[:len(PubKeyPrefix)] == PubKeyPrefix {
			raw = raw[len(PubKeyPrefix):]
			b, err := b64.DecodeString(raw)
			if err != nil {
				panic(err)
			}

			pub = NewPubKey(b)
			return
		} else if raw[:len(SecKeyPrefix)] == SecKeyPrefix && (onlySecret || onlySub) {
			raw = raw[len(SecKeyPrefix):]
			b, err := b64.DecodeString(raw)
			if err != nil {
				panic(err)
			}
			if onlySub {
				sub = b[len(b)-SubKeySize:]
				return
			}

			if len(b) == SecKeyEncSize+SaltSize+SubKeySize {
				pwd := readPassword("Password: ")
				salt := make([]byte, SaltSize)
				copy(salt, b[SecKeyEncSize:SecKeyEncSize+SaltSize])
				sb := make([]byte, SubKeySize)
				copy(sb, b[len(b)-SubKeySize:])

				b = b[:SecKeyEncSize]
				derived := argon2.IDKey(
					[]byte(pwd),
					append(salt, []byte("stern-derive-for-secret-key")...),
					ArgonTimeFactor,
					ArgonMemoryFactor,
					ArgonCPUFactor,
					SharedKeySize)

				raw := DecryptOnce(derived, b, []byte("stern-secret-key"))
				raw = append(raw, sb...)
				sec = NewSecKey(raw)
				return
			} else {
				sec = NewSecKey(b)
				return
			}
		}
	}

	panic("keys not found")
}
