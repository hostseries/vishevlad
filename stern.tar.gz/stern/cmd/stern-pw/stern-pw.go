package main

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/sha3"
	"encoding/binary"
	"encoding/json"
	"flag"
	"fmt"
	"hash"
	"io"
	"log"
	"net"
	"os"
	"path/filepath"
	"stern"
	"strings"
	"time"

	"github.com/gookit/color"
	"golang.org/x/crypto/argon2"
	"golang.org/x/crypto/hkdf"
)

const socketName = "stern-secrets-server.socket"

type Request struct {
	Method     string `json:"method"`
	Secret     Secret `json:"secret"`
	Id         string `json:"id"`
	SessionKey string `json:"session-key"`
}

type Response struct {
	Secret   Secret `json:"secret"`
	Metadata string `json:"metadata"`
	Status   string `json:"status"`
}

type Secret struct {
	Secret         []byte
	Add            time.Time
	Ttl            time.Duration
	MaxGetTimes    int
	Metadata       string
	uniqueIdentity int64
}

var reader = rand.Reader

var (
	digits       = "0123456789"
	lowerLetters = "abcdefghijklmnopqrstuvwxyz"
	letters      = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	special      = "+-&%$#@*:;!?)(/)[]{}~|=^_><.,"

	T1               = strings.Split(digits+lowerLetters+letters+special, "")
	T2               = strings.Split(digits+lowerLetters+letters, "")
	T3               = strings.Split(digits+lowerLetters, "")
	T4               = onlyLetters
	T5               = strings.Split(digits, "")
	T6               = wordlist
	onlyLetters      = strings.Split(lowerLetters+letters, "")
	onlyLowerLetters = strings.Split(lowerLetters, "")
	forPrint         = strings.Split("-----+++<>!:", "")
)

var (
	pwdType  uint
	pwdTypes = [][]string{T1, T2, T3, T4, T5, T6}
)

func main() {
	log.SetFlags(0)
	color.SetOutput(os.Stderr)

	var (
		length         uint
		delim          string
		context        string
		outputFilename string
		bip39          bool
	)

	flag.UintVar(&length, "length", 31, "")
	flag.UintVar(&length, "n", 31, "")
	flag.UintVar(&pwdType, "type", 1, "")
	flag.UintVar(&pwdType, "t", 1, "")
	flag.StringVar(&delim, "delim", " ", "")
	flag.StringVar(&delim, "d", " ", "")
	flag.BoolVar(&bip39, "bip39", false, "generate bip39 seed phrase (24 words only)")
	flag.StringVar(&context, "context", "", "")
	flag.StringVar(&context, "c", "", "")
	flag.StringVar(&outputFilename, "o", "", "")

	flag.Parse()

	if (pwdType != 6 && length < 3) || (pwdType == 6 && length < 1) {
		log.Fatal("invalid password length")
	}

	var contextHash []byte

	if context != "" {
		homedir, err := os.UserHomeDir()
		if err != nil {
			panic(err)
		}

		pwdTypeC := pwdType
		if bip39 {
			pwdTypeC = 7
		}

		allContext := []byte(fmt.Sprintf("stern-password-generation-from-context-%s-%d-%d", strings.ToLower(context), pwdTypeC, length))

		func() {
			socketPath := filepath.Join(homedir, ".config/stern", socketName)
			conn, err := net.Dial("unix", socketPath)
			if err != nil {
				return
			}
			defer conn.Close()

			encoder := json.NewEncoder(conn)
			decoder := json.NewDecoder(conn)

			var req Request
			var resp Response

			req.SessionKey = os.Getenv("STERN_SESSION_KEY")
			req.Secret.Secret = allContext
			req.Method = "context_hash"
			if err := encoder.Encode(req); err != nil {
			}

			if err := decoder.Decode(&resp); err != nil {
			}

			contextHash = resp.Secret.Secret
		}()

		if len(contextHash) == 0 {
			masterKeyPath := filepath.Join(homedir, ".config/stern/master.key")
			f, err := os.Open(masterKeyPath)
			if err != nil {
				panic(err)
			}

			sec := stern.ParseSecKey(f)
			if err != nil {
				panic(err)
			}

			allContext = append(allContext, sec.PubKey().Bytes()...)
			allContext = append(allContext, sec.Bytes()[:24]...)
			allContext = append(allContext, sec.SubKey()...)
			h := sha3.Sum512(allContext)
			contextHash = h[:]
		}
		key := argon2.IDKey(contextHash, []byte("stern-default-salt"), 1, 1<<20, 8, 64)

		hk := hkdf.New(
			func() hash.Hash { return sha3.New512() },
			key,
			nil,
			nil,
		)
		reader = hk
	}

	shakeSeed := make([]byte, 32)
	io.ReadFull(reader, shakeSeed)

	if pwdType < 1 || int(pwdType) > len(pwdTypes) {
		log.Fatalf("password type invalid, must be 1-%d", len(pwdTypes))
	}

	w := pwdTypes[pwdType-1]

	pwdLine := make([]byte, 0, 100)
	if bip39 {
		getBip39(&pwdLine)
	} else {
		createPwd := func() {
			for i := uint(1); i <= length; i++ {
				pwdLine = append(pwdLine, choice(w)...)
				if pwdType == 6 && i < length {
					pwdLine = append(pwdLine, []byte(delim)...)
				}
			}

			if pwdType == 2 {
				pwdLine[0] = choice(onlyLetters)[0]
			} else if pwdType == 3 {
				pwdLine[0] = choice(onlyLowerLetters)[0]
			}

		}

		createPwd()
		if (1 <= pwdType) && (pwdType <= 4) {
			for !checkPwd(pwdLine) {
				pwdLine = pwdLine[:0]
				createPwd()
			}
		}
	}

	fmt.Fprintln(os.Stderr)

	shake := sha3.NewSHAKE256()
	shake.Write(shakeSeed)
	reader = shake

	fw1 := strings.Split(string(choice(T6)), "")
	fw2 := strings.Split(string(choice(T6)), "")
	fmt.Println(string(pwdLine))

	x1 := getInt() % (6 - 1)
	x2 := getInt() % (12 - 1)

	for i := 0; i < 6; i++ {
		fmt.Fprintln(os.Stderr)
		for j := 0; j < 12; j++ {
			if i == 2 && j > 1 && j < len(fw1)+2 {
				color.RGB(uint8(getInt()%200), 175, 255).Print(" ", fw1[j-2])
			} else if i == 3 && j > 1 && j < len(fw2)+2 {
				color.RGB(uint8(getInt()%200), 155, 255).Print(" ", fw2[j-2])
			} else {
				if i == x1 || i == (x1+1) &&
					j == x2 || j == (x2+1) {
					color.RGB(15, 230, 170).Print(" ", string(choice(forPrint)))
				} else {
					color.RGB(uint8(getInt()%230), 150, 70).Print(" ", string(choice(forPrint)))
				}
			}
		}
	}
	fmt.Fprintln(os.Stderr)
}

func checkPwd(pwdLine []byte) bool {
	pwd := string(pwdLine)

	verif := strings.ContainsAny(pwd, digits)

	if pwdType == 4 {
		verif = strings.ContainsAny(pwd, letters+lowerLetters)
	}

	if pwdType == 3 {
		verif = verif && strings.ContainsAny(pwd, lowerLetters) && strings.ContainsAny(pwd, digits)
	} else if pwdType == 2 {
		verif = verif && strings.ContainsAny(pwd, lowerLetters) && strings.ContainsAny(pwd, digits) && strings.ContainsAny(pwd, letters)
	} else if pwdType == 1 {
		verif = verif && ((strings.ContainsAny(pwd, lowerLetters) && strings.ContainsAny(pwd, digits) && strings.ContainsAny(pwd, letters) && strings.ContainsAny(pwd, special)) || len(pwdLine) < 4)
	}
	return verif
}

func getBip39(pwdLine *[]byte) {
	key := make([]byte, 32)
	if _, err := io.ReadFull(reader, key); err != nil {
		panic(err)
	}

	h := sha256.Sum256(key)
	key = append(key, h[:][0])
	for _, i := range to11bitChunks(key) {
		*pwdLine = append(*pwdLine, wordlist[i]...)
		*pwdLine = append(*pwdLine, ' ')
	}
}

func to11bitChunks(data []byte) []uint16 {
	var result []uint16
	var bitBuffer uint32
	var bitCount int

	for _, b := range data {
		bitBuffer = (bitBuffer << 8) | uint32(b)
		bitCount += 8

		for bitCount >= 11 {
			value := (bitBuffer >> (bitCount - 11)) & 0x7FF
			result = append(result, uint16(value))
			bitCount -= 11
			bitBuffer &= (1 << bitCount) - 1
		}
	}
	return result
}

func choice(w []string) []byte {
	return []byte(w[getInt()%len(w)])
}

func getInt() int {
	b := make([]byte, 2)
	if _, err := io.ReadFull(reader, b); err != nil {
		panic(err)
	}

	return int(binary.BigEndian.Uint16(b))
}
