package main

import (
	"bufio"
	"bytes"
	"crypto/rand"
	"crypto/sha3"
	"encoding/base64"
	"encoding/binary"
	"flag"
	"fmt"
	"hash"
	"io"
	"log"
	"os"
	"stern"
	"strings"
	"time"

	"github.com/cosmos/btcutil/bech32"
	"golang.org/x/crypto/argon2"
	"golang.org/x/crypto/hkdf"
	"golang.org/x/term"
)

var b64 = base64.RawStdEncoding.Strict()

func main() {
	log.SetFlags(0)

	var (
		fromPattern    bool
		age            bool
		noPass         bool
		decryptKey     bool
		changePass     bool
		outputFilename string
	)

	flag.BoolVar(&fromPattern, "from-pattern", false, "")
	flag.BoolVar(&noPass, "no-pass", false, "")
	flag.BoolVar(&age, "age", false, "")
	flag.BoolVar(&decryptKey, "decrypt-key", false, "")
	flag.BoolVar(&decryptKey, "d", false, "")
	flag.BoolVar(&changePass, "change-pass", false, "")
	flag.StringVar(&outputFilename, "o", "", "")
	flag.Parse()

	if decryptKey || changePass {
		keypath := flag.Args()[0]
		f, err := os.Open(keypath)
		if err != nil {
			panic(err)
		}
		defer f.Close()

		if decryptKey {
			sec := stern.ParseSecKey(
				bufio.NewReader(f),
			)
			fmt.Print(string(sec.Bytes()))
		} else {
			changePassword(f)
		}
		os.Exit(0)
	}

	var res string
	if fromPattern {
		res = keygenFromPattern(noPass, age)
	} else {
		res = keygen(rand.Reader, noPass, age)
	}

	if outputFilename == "" {
		fmt.Println(res)
	} else {
		stern.SafeCopyToFile(outputFilename, bytes.NewReader([]byte(res)))
	}

}

func ArgonDeriveForPattern(secret, salt []byte, n int) []byte {
	return argon2.IDKey(
		secret, salt,
		stern.ArgonTimeFactor*3,
		stern.ArgonMemoryFactor*3,
		stern.ArgonCPUFactor,
		uint32(n))
}

func readFromTerminal(prompt string) string {
	tty, err := os.OpenFile("/dev/tty", os.O_RDWR, 0)
	if err != nil {
		panic(err)
	}

	defer tty.Close()

	t := term.NewTerminal(tty, prompt)
	line, err := t.ReadLine()
	if err != nil {
		panic(err)

	}
	fmt.Fprintln(tty, "\033c")

	var lines []string
	for _, s := range strings.Split(line, " ") {
		s = strings.TrimSpace(s)
		if len(s) > 0 {
			s = strings.ToLower(s)
			lines = append(lines, s)
		}
	}

	line = strings.Join(lines, " ")
	return line
}

func keygen(rand io.Reader, noPass, age bool) (keysString string) {
	if age {
		ageKey := make([]byte, 32)
		if _, err := io.ReadFull(rand, ageKey); err != nil {
			panic(err)
		}

		encoded, err := bech32.EncodeFromBase256("AGE-SECRET-KEY-PQ-", ageKey)
		if err != nil {
			log.Fatalf("Error: %s", err)
		}
		keysString = strings.ToUpper(encoded)
		return
	} else {
		pub, sec := stern.GenerateKeys(rand)
		keysString = serializeKeys(
			pub,
			sec,
			noPass)
		return
	}
}

func serializeKeys(pub *stern.PubKey, sec *stern.SecKey, noPass bool) (keysString string) {
	pubString := stern.PubKeyPrefix + EncodeToString(pub.Bytes())
	var secString string

	if !noPass {
		pwd := readPassword("New password: ", "Confirm: ", true)

		salt := make([]byte, stern.SaltSize)
		if _, err := io.ReadFull(rand.Reader, salt); err != nil {
			panic(err)
		}

		derived := argon2.IDKey(
			[]byte(pwd),
			append(salt, []byte("stern-derive-for-secret-key")...),
			stern.ArgonTimeFactor,
			stern.ArgonMemoryFactor,
			stern.ArgonCPUFactor,
			stern.SharedKeySize)

		encSecKey := stern.EncryptOnce(derived, sec.Bytes()[:stern.SecKeySize-stern.SubKeySize], []byte("stern-secret-key"))
		encSecKey = append(encSecKey, salt...)
		encSecKey = append(encSecKey, sec.Bytes()[stern.SecKeySize-stern.SubKeySize:]...)

		secString = stern.SecKeyPrefix + EncodeToString(encSecKey)
	} else {
		secString = stern.SecKeyPrefix + EncodeToString(sec.Bytes())
	}
	keysString += fmt.Sprintf("stern-keys: MLKEM-1024 + X25519\ncreated: %s\n\n", time.Now().Format(time.RFC1123))
	keysString += pubString + "\n\n"
	keysString += secString + "\n"
	return
}

func changePassword(f *os.File) {
	src := bufio.NewReader(f)
	sec := stern.ParseSecKey(src)
	r := bytes.NewReader(
		[]byte(serializeKeys(
			sec.PubKey(),
			sec,
			false)))

	if err := stern.SafeCopyToFile(f.Name(), r); err != nil {
		panic(err)
	}
}

func keygenFromPattern(noPass, age bool) (keysString string) {
	secretLine := []byte(readFromTerminal("secret: "))
	if len(secretLine) < 75 {
		log.Fatal("secret too small")
	}

	context := "stern-key"
	if age {
		context = "age-pq-key"
	}

	log.Println("Generation...")

	derived := ArgonDeriveForPattern(
		secretLine,
		[]byte("stern-key-generation-from-secret-pattern"),
		64)

	nRaw := make([]byte, 4)
	copy(nRaw, derived)
	n := int(binary.BigEndian.Uint32(nRaw))
	wprint := strings.ToUpper(wordlist_rus[n%len(wordlist_rus)])

	rand := hkdf.New(
		func() hash.Hash { return sha3.New512() },
		derived,
		[]byte(context),
		[]byte("stern-key-generation-from-secret-pattern"),
	)

	log.Println()
	log.Printf("WORD-PRINT: %s\n", wprint)
	log.Println()
	return keygen(rand, noPass, age)
}

func EncodeToString(data []byte) string {
	return b64.EncodeToString(data)
}

func DecodeToString(encoded string) []byte {
	decoded, err := b64.DecodeString(encoded)
	if err != nil {
		panic(err)
	}
	return decoded
}

func clearLine(out io.Writer) {
	fmt.Fprintf(out, "\n\033[F\033[K")
}

func readPassword(prompt, secondPrompt string, confirm bool) (pwd []byte) {
	tty, err := os.OpenFile("/dev/tty", os.O_RDWR, 0)
	if err != nil {
		panic(err)
	}

	fmt.Fprint(tty, prompt)
	pwd, err = term.ReadPassword(int(tty.Fd()))
	if err != nil {
		panic("read password: internal error: " + err.Error())
	}
	clearLine(tty)

	if isBadPassword(pwd) {
		log.Fatal("bad password")
	}

	if confirm {
		fmt.Fprint(tty, secondPrompt)
		pwdc, err := term.ReadPassword(int(tty.Fd()))
		if err != nil {
			panic("read password: internal error: " + err.Error())
		}
		clearLine(tty)
		if !bytes.Equal(pwd, pwdc) {
			log.Fatal("\nPasswords do not match")
		}
	}
	return pwd
}

func isBadPassword(pwd []byte) bool {
	return len(bytes.TrimSpace(pwd)) == 0
}
