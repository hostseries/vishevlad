package main

import (
	"crypto/sha256"
	"flag"
	"fmt"
	"io"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"sync"
)

func main() {
	log.SetFlags(0)
	flag.Parse()
	rootDir := flag.Args()[0]
	p, err := os.Open(rootDir)
	if err != nil {
		log.Fatal(err)
	}
	defer p.Close()

	paths := make(chan string, 1000)

	go func() {
		filepath.WalkDir(rootDir,
			func(path string, d fs.DirEntry, err error) error {
				if d.Type().IsRegular() {
					paths <- path
				}
				if err != nil {
					panic(err)
				}
				return err
			})
		close(paths)
	}()

	res := make(chan []byte, 1000)
	wg := new(sync.WaitGroup)
	for i := 1; i <= 8; i++ {
		wg.Add(1)
		go func(wg *sync.WaitGroup) {
			defer wg.Done()
			worker(paths, res)
		}(wg)
	}

	go func() {
		wg.Wait()
		close(res)
	}()

	hh := make([]byte, 32)

	for i := range res {
		xor(hh, i)
	}
	fmt.Printf("%x\n", hh)

}

func xor(x1, x2 []byte) []byte {
	for i, j := range x2 {
		x1[i] ^= j
	}
	return x1
}

func worker(paths chan string, res chan []byte) {
	hh := make([]byte, 32)
	for path := range paths {
		h := sha256.New()
		f, err := os.Open(path)
		if err != nil {
			panic(err)
		}

		_, err = io.Copy(h, f)
		if err != nil {
			panic(err)
		}
		f.Close()
		xor(hh, h.Sum(nil)[:])
	}
	res <- hh
}
