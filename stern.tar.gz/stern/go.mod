module stern

go 1.26.0

require (
	github.com/cosmos/btcutil v1.0.5
	github.com/gookit/color v1.6.0
	golang.org/x/crypto v0.51.0
	golang.org/x/sys v0.44.0
	golang.org/x/term v0.43.0
)

require github.com/xo/terminfo v0.0.0-20220910002029-abceb7e1c41e // indirect
